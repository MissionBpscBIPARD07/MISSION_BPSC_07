# Mission BPSC (BIPARD) — PT Test Series MVP

This is a deployable starter application with:
- Student signup/login (Supabase Auth)
- Published test catalogue
- Razorpay order creation and server-side signature verification
- Paid-test access checks
- Timed browser exam interface
- Server-calculated score: +1 correct, -1/3 incorrect, 0 skipped
- Student attempt history
- Admin-only test and question creation

## Important before launch
This is a working starter, not a live hosted website. You must create your own Supabase and Razorpay accounts, configure credentials, deploy the app, and test payments. Never share your service-role key or Razorpay secret. Use Razorpay test mode first. Production payments require the account holder to complete the provider's KYC and legal/business requirements. If the owner is under 18, a parent/legal guardian or eligible adult must handle account ownership and payment-provider onboarding.

## 1. Create Supabase backend
1. Create a project at https://supabase.com/
2. Open SQL Editor and run `schema.sql`.
3. In Project Settings → API, copy Project URL and `service_role` key for the server.
4. Also copy the `anon` / publishable key. Add `SUPABASE_ANON_KEY` to `.env` (and add it to `/api/config` response in `server.js`; see note below).
5. In Authentication settings, configure your site URL and email confirmation policy.

## 2. Configure environment
Copy `.env.example` to `.env`, then fill:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `SUPABASE_ANON_KEY`
- `RAZORPAY_KEY_ID`
- `RAZORPAY_KEY_SECRET`

In `server.js`, include `supabaseAnonKey: process.env.SUPABASE_ANON_KEY || ''` in `/api/config` (the starter already reads it; add the variable to `.env`).

## 3. Install and run locally
Requires Node.js 20+.
```bash
npm install
cp .env.example .env
# edit .env with your own credentials
npm start
```
Open http://localhost:3000

## 4. Make your account admin
1. Sign up on your site.
2. In Supabase → Authentication → Users, copy your user's UUID.
3. Run in SQL Editor:
```sql
update public.profiles set role = 'admin' where id = 'YOUR-USER-UUID';
```
4. Reload and use `/` then Admin Panel is available through the app's API. (Admin panel section is currently exposed in the starter UI; all admin API actions are protected server-side.)

## 5. Add tests
- Login with admin account.
- Use Admin Panel to create a test.
- Add questions one by one with exactly four options.
- Publish the test.
- Test ID is displayed after creation.

## 6. Payment setup
- Start with Razorpay Test Mode keys.
- Test order creation, successful payment, failed payment, and duplicate purchase behavior.
- Before live mode, complete Razorpay onboarding/KYC and replace test keys with live keys.
- For stronger production assurance, configure Razorpay webhooks and reconcile payment status server-side before granting access. The included signature verification is the basic checkout verification path.

## 7. Deploy
Deploy the Node app to a Node-compatible host such as Render, Railway, or a VPS. Set all environment variables in the hosting dashboard. Add your deployed HTTPS URL to Supabase Auth redirect/site URL settings and Razorpay allowed website settings. Connect a custom domain after deployment.

## Security notes
- Do not put Supabase service-role key or Razorpay secret in browser code.
- The answer key is never sent to the browser; scoring is performed on the server.
- Add rate limiting, audit logs, backups, webhook reconciliation, privacy policy, terms, refund policy, and support contact before public commercial launch.
- The current exam timer is browser-side; add server-issued attempt start/expiry timestamps for strict high-stakes timing.
