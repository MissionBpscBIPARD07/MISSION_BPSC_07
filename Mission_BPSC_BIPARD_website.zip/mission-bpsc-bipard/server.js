import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import Razorpay from 'razorpay';
import crypto from 'crypto';
import { createClient } from '@supabase/supabase-js';

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const required = ['SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY'];
for (const key of required) if (!process.env[key]) console.warn(`Missing ${key}`);
const db = createClient(process.env.SUPABASE_URL || 'https://example.supabase.co',
  process.env.SUPABASE_SERVICE_ROLE_KEY || 'missing');
const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET }) : null;

async function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer /, '');
  if (!token) return res.status(401).json({ error: 'Login required' });
  const { data, error } = await db.auth.getUser(token);
  if (error || !data.user) return res.status(401).json({ error: 'Invalid session' });
  req.user = data.user; next();
}
async function admin(req, res, next) {
  const { data } = await db.from('profiles').select('role').eq('id', req.user.id).single();
  if (data?.role !== 'admin') return res.status(403).json({ error: 'Admin access required' });
  next();
}

app.get('/api/config', (_req,res) => res.json({ supabaseUrl: process.env.SUPABASE_URL || '', supabaseAnonKey: process.env.SUPABASE_ANON_KEY || '', razorpayKeyId: process.env.RAZORPAY_KEY_ID || '' }));

app.get('/api/tests', async (_req,res) => {
  const { data, error } = await db.from('tests').select('id,title,description,price_paise,duration_minutes').eq('published',true).order('created_at',{ascending:false});
  if (error) return res.status(500).json({error:error.message});
  res.json(data || []);
});

app.get('/api/tests/:id/questions', auth, async (req,res) => {
  const testId = Number(req.params.id);
  const { data: test } = await db.from('tests').select('id,price_paise').eq('id',testId).eq('published',true).single();
  if (!test) return res.status(404).json({error:'Test not found'});
  if (test.price_paise > 0) {
    const { data: purchase } = await db.from('purchases').select('id').eq('user_id',req.user.id).eq('test_id',testId).eq('status','paid').maybeSingle();
    if (!purchase) return res.status(403).json({error:'Please purchase this test first'});
  }
  const { data, error } = await db.from('questions').select('id,question_text,options,sort_order').eq('test_id',testId).order('sort_order');
  if (error) return res.status(500).json({error:error.message});
  res.json(data || []);
});

app.post('/api/payment/order', auth, async (req,res) => {
  if (!razorpay) return res.status(503).json({error:'Payment gateway is not configured yet'});
  const testId = Number(req.body.testId);
  const { data: test } = await db.from('tests').select('id,title,price_paise').eq('id',testId).eq('published',true).single();
  if (!test) return res.status(404).json({error:'Test not found'});
  if (test.price_paise === 0) return res.status(400).json({error:'This test is free'});
  const { data: already } = await db.from('purchases').select('id').eq('user_id',req.user.id).eq('test_id',testId).eq('status','paid').maybeSingle();
  if (already) return res.status(409).json({error:'Already purchased'});
  const order = await razorpay.orders.create({amount:test.price_paise,currency:'INR',receipt:`mbpsc_${req.user.id.slice(0,8)}_${testId}`});
  await db.from('purchases').upsert({user_id:req.user.id,test_id:testId,razorpay_order_id:order.id,amount_paise:test.price_paise,status:'created'},{onConflict:'user_id,test_id'});
  res.json({orderId:order.id,amount:order.amount,currency:order.currency,keyId:process.env.RAZORPAY_KEY_ID,testTitle:test.title});
});

app.post('/api/payment/verify', auth, async (req,res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
  const expected = crypto.createHmac('sha256',process.env.RAZORPAY_KEY_SECRET || '')
    .update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
  if (!razorpay_signature || !crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(razorpay_signature))) {
    return res.status(400).json({error:'Payment verification failed'});
  }
  const { data: purchase } = await db.from('purchases').select('id,user_id').eq('razorpay_order_id',razorpay_order_id).eq('user_id',req.user.id).single();
  if (!purchase) return res.status(404).json({error:'Order not found'});
  const { error } = await db.from('purchases').update({razorpay_payment_id,status:'paid'}).eq('id',purchase.id);
  if (error) return res.status(500).json({error:error.message});
  res.json({success:true});
});

app.post('/api/attempts', auth, async (req,res) => {
  const { testId, answers } = req.body;
  const { data: test } = await db.from('tests').select('id,price_paise').eq('id',testId).eq('published',true).single();
  if (!test) return res.status(404).json({error:'Test not found'});
  if (test.price_paise > 0) {
    const { data: p } = await db.from('purchases').select('id').eq('user_id',req.user.id).eq('test_id',testId).eq('status','paid').maybeSingle();
    if (!p) return res.status(403).json({error:'Purchase required'});
  }
  const { data: qs, error: qErr } = await db.from('questions').select('id,correct_option').eq('test_id',testId);
  if (qErr) return res.status(500).json({error:qErr.message});
  let correct=0, wrong=0, skipped=0;
  for (const q of qs || []) {
    const a = answers?.[q.id];
    if (a === undefined || a === null || a === '') skipped++;
    else if (Number(a) === q.correct_option) correct++;
    else wrong++;
  }
  const score = correct - wrong/3;
  const { data, error } = await db.from('attempts').insert({user_id:req.user.id,test_id:testId,answers,correct_count:correct,wrong_count:wrong,skipped_count:skipped,score}).select('id,correct_count,wrong_count,skipped_count,score').single();
  if (error) return res.status(500).json({error:error.message});
  res.json(data);
});

app.get('/api/my/attempts', auth, async (req,res) => {
  const { data, error } = await db.from('attempts').select('id,test_id,correct_count,wrong_count,skipped_count,score,submitted_at,tests(title)').eq('user_id',req.user.id).order('submitted_at',{ascending:false});
  if (error) return res.status(500).json({error:error.message});
  res.json(data || []);
});

app.get('/api/admin/tests', auth, admin, async (_req,res) => {
  const { data,error } = await db.from('tests').select('*').order('created_at',{ascending:false});
  if (error) return res.status(500).json({error:error.message});
  res.json(data || []);
});
app.post('/api/admin/tests', auth, admin, async (req,res) => {
  const { title,description,price_rupees,duration_minutes,published } = req.body;
  const { data,error } = await db.from('tests').insert({title,description,price_paise:Math.round(Number(price_rupees||0)*100),duration_minutes:Number(duration_minutes||120),published:!!published}).select().single();
  if (error) return res.status(400).json({error:error.message});
  res.json(data);
});
app.post('/api/admin/questions', auth, admin, async (req,res) => {
  const { test_id,question_text,options,correct_option,explanation,sort_order } = req.body;
  if (!Array.isArray(options) || options.length !== 4) return res.status(400).json({error:'Exactly four options required'});
  const { data,error } = await db.from('questions').insert({test_id,question_text,options,correct_option,explanation,sort_order:sort_order||0}).select().single();
  if (error) return res.status(400).json({error:error.message});
  res.json(data);
});
app.patch('/api/admin/tests/:id', auth, admin, async (req,res) => {
  const patch = {};
  for (const k of ['title','description','published','duration_minutes']) if (k in req.body) patch[k]=req.body[k];
  if ('price_rupees' in req.body) patch.price_paise=Math.round(Number(req.body.price_rupees)*100);
  const { data,error } = await db.from('tests').update(patch).eq('id',req.params.id).select().single();
  if (error) return res.status(400).json({error:error.message});
  res.json(data);
});

app.get('/api/health',(_req,res)=>res.json({ok:true,service:'Mission BPSC API'}));
const port = process.env.PORT || 3000;
app.listen(port,()=>console.log(`Mission BPSC running on http://localhost:${port}`));
